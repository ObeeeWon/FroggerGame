
public class GameProperties {
	
	public static final int SCREEN_HEIGHT = 730;
	public static final int SCREEN_WIDTH = 1551;
	public static final int CHARACTER_STEP = 60;
	
	//GameProperties myProperties = new GameProperties;
	//myProperties.CHARACTER_STEP
	
	//GameProperties.SCREEN_WIDTH

}
